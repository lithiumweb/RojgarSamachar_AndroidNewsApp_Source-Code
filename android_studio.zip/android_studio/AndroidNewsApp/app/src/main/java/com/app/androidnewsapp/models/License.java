package com.app.androidnewsapp.models;

import java.io.Serializable;

public class License implements Serializable {

    public String item_id;
    public String item_name;
    public String license_type;

}
